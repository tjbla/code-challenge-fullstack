<template>
  <q-page class="flex flex-center">
    <h3>Good luck!</h3>
  </q-page>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "IndexPage",
});
</script>
