### Full stack Code Challenge

In this folder, you can find two repositories that implement the front end and back end for a cooking recipe book.

Please, read the instructions in the README files of both repositories carefully and complete all the requirements. You will have 1 hour and 30 min to complete the tasks. After that time, we will have a brief code review meeting. You can send the test after the code reviewing by email or as a Git remote repository.

We wish you good luck!
